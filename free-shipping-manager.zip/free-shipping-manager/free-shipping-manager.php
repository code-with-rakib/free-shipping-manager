<?php
/**
 * Plugin Name: Free Shipping Manager for WooCommerce
 * Plugin URI:  https://github.com/code-with-rakib/free-shipping-manager
 * Description: নির্দিষ্ট পণ্যের জন্য ফ্রি ডেলিভারি সেট করার অপশন এবং একটি প্রিমিয়াম অ্যাডমিন ড্যাশবোর্ড।
 * Version:     1.1.0
 * Author:      Rakib Hasan
 * Author URI:  https://codewithrakib.com
 * License:     GPL2
 * Text Domain: free-shipping-manager
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * ১. প্রোডাক্ট এডিট পেজে চেকবক্স যোগ করা
 */
add_action( 'woocommerce_product_options_general_product_data', 'fsm_add_free_shipping_field' );
function fsm_add_free_shipping_field() {
    echo '<div class="options_group">';
    woocommerce_wp_checkbox( array(
        'id'            => '_is_exclusive_free',
        'label'         => __( 'ফ্রি ডেলিভারি?', 'fsm' ),
        'description'   => __( 'কার্টে শুধু এই পণ্যটি থাকলে অন্য সব শিপিং অপশন হাইড হয়ে যাবে।', 'fsm' ),
    ) );
    echo '</div>';
}

add_action( 'woocommerce_process_product_meta', 'fsm_save_free_shipping_field' );
function fsm_save_free_shipping_field( $post_id ) {
    update_post_meta( $post_id, '_is_exclusive_free', isset( $_POST['_is_exclusive_free'] ) ? 'yes' : 'no' );
}

/**
 * ২. শিপিং লজিক: সব পণ্য ফ্রি হলে শুধুমাত্র 'Free Shipping' দেখানো
 */
add_filter( 'woocommerce_package_rates', 'fsm_force_single_free_shipping', 100, 2 );
function fsm_force_single_free_shipping( $rates, $package ) {
    $total_items = count( $package['contents'] );
    $free_shipping_count = 0;

    foreach ( $package['contents'] as $item ) {
        if ( get_post_meta( $item['product_id'], '_is_exclusive_free', true ) === 'yes' ) {
            $free_shipping_count++;
        }
    }

    // যদি কার্টের প্রতিটি পণ্যই ফ্রি শিপিংয়ের আওতাভুক্ত হয়
    if ( $total_items === $free_shipping_count ) {
        $new_rates = array();
        
        foreach ( $rates as $rate_id => $rate ) {
            // যদি আগে থেকেই কোনো ফ্রি শিপিং মেথড সেট করা থাকে
            if ( 'free_shipping' === $rate->method_id ) {
                $new_rates[ $rate_id ] = $rate;
                break; 
            }
        }

        // যদি ফ্রি শিপিং মেথড খুঁজে না পাওয়া যায়, তবে সব মেথডকে ফ্রি হিসেবে রিনেম করা
        if ( empty( $new_rates ) ) {
            foreach ( $rates as $rate_id => $rate ) {
                $rate->cost = 0;
                $rate->label = __( 'ফ্রি শিপিং (Free Shipping)', 'fsm' );
                $new_rates[ $rate_id ] = $rate;
                break; // শুধু একটি অপশন দেখাবে
            }
        }

        return $new_rates;
    }

    return $rates;
}

/**
 * ৩. উন্নত অ্যাডমিন ড্যাশবোর্ড ও ডেভেলপার প্রোফাইল
 */
add_action( 'admin_menu', 'fsm_dashboard_menu' );
function fsm_dashboard_menu() {
    add_menu_page( 
        'Shipping Manager', 
        'ফ্রি শিপিং প্যানেল', 
        'manage_options', 
        'fsm-dashboard', 
        'fsm_render_dashboard', 
        'dashicons-truck', // আইকন আপডেট করা হয়েছে
        60 
    );
}

function fsm_render_dashboard() {
    ?>
    <style>
        .fsm-container { margin: 20px 20px 0 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .fsm-card { background: #fff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); overflow: hidden; border: 1px solid #e2e8f0; }
        .fsm-header { background: #f8fafc; padding: 20px; border-bottom: 1px solid #e2e8f0; display: flex; align-items: center; justify-content: space-between; }
        .fsm-header h1 { margin: 0; font-size: 20px; color: #1e293b; display: flex; align-items: center; }
        .fsm-header h1 span { color: #3b82f6; margin-right: 10px; }
        .fsm-table { width: 100%; border-collapse: collapse; }
        .fsm-table th { background: #f1f5f9; text-align: left; padding: 15px; color: #64748b; font-weight: 600; text-transform: uppercase; font-size: 12px; }
        .fsm-table td { padding: 15px; border-bottom: 1px solid #f1f5f9; color: #334155; vertical-align: middle; }
        .fsm-badge { background: #dcfce7; color: #166534; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: 500; }
        .dev-card { margin-top: 30px; background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%); color: #fff; border-radius: 15px; padding: 30px; display: flex; align-items: center; position: relative; overflow: hidden; }
        .dev-card::after { content: ''; position: absolute; right: -50px; bottom: -50px; width: 200px; height: 200px; background: rgba(59, 130, 246, 0.1); border-radius: 50%; }
        .dev-img { width: 110px; height: 110px; border-radius: 50%; border: 4px solid #3b82f6; object-fit: cover; margin-right: 30px; z-index: 1; }
        .dev-info { z-index: 1; }
        .dev-info h2 { margin: 0 0 5px 0; color: #fff; font-size: 24px; }
        .dev-info p { margin: 5px 0; opacity: 0.8; font-size: 14px; }
        .dev-contact { margin-top: 15px; display: inline-block; background: #3b82f6; color: #fff; text-decoration: none; padding: 10px 25px; border-radius: 8px; font-weight: 600; transition: 0.3s; }
        .dev-contact:hover { background: #2563eb; color: #fff; }
    </style>

    <div class="fsm-container">
        <div class="fsm-card">
            <div class="fsm-header">
                <h1><span class="dashicons dashicons-shield"></span> একটিভ ফ্রি ডেলিভারি আইটেম</h1>
                <span class="fsm-badge">লাইভ মনিটরিং</span>
            </div>
            
            <table class="fsm-table">
                <thead>
                    <tr>
                        <th>ছবি</th>
                        <th>পণ্যের নাম</th>
                        <th>মূল্য</th>
                        <th>স্ট্যাটাস</th>
                        <th>অ্যাকশন</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $products = new WP_Query( array(
                        'post_type' => 'product',
                        'posts_per_page' => -1,
                        'meta_query' => array( array( 'key' => '_is_exclusive_free', 'value' => 'yes' ) )
                    ) );

                    if ( $products->have_posts() ) :
                        while ( $products->have_posts() ) : $products->the_post();
                            $product = wc_get_product( get_the_ID() );
                            ?>
                            <tr>
                                <td><?php echo $product->get_image( array( 45, 45 ), array( 'style' => 'border-radius:6px; box-shadow: 0 2px 5px rgba(0,0,0,0.1);' ) ); ?></td>
                                <td><strong><?php the_title(); ?></strong><br><small style="color:#94a3b8">ID: #<?php the_ID(); ?></small></td>
                                <td style="color: #059669; font-weight: 600;"><?php echo $product->get_price_html(); ?></td>
                                <td><span class="fsm-badge" style="background:#e0f2fe; color:#0369a1;">ফ্রি শিপিং সক্রিয়</span></td>
                                <td><a href="<?php echo get_edit_post_link(); ?>" class="button" style="border-radius: 6px;">ম্যানেজ</a></td>
                            </tr>
                            <?php
                        endwhile;
                        wp_reset_postdata();
                    else :
                        echo '<tr><td colspan="5" style="text-align:center; padding:40px; color:#94a3b8;">কোনো পণ্য খুঁজে পাওয়া যায়নি।</td></tr>';
                    endif;
                    ?>
                </tbody>
            </table>
        </div>

        <div class="dev-card">
            <img src="https://codewithrakib.com/assets/images/hero.png" class="dev-img" alt="Rakib Hasan">
            <div class="dev-info">
                <p style="text-transform: uppercase; letter-spacing: 1px; color: #3b82f6; font-weight: bold; margin-bottom: 5px;">প্লাগইন ডেভেলপার</p>
                <h2>Rakib Hasan</h2>
                <p>এক্সপার্ট ওয়ার্ডপ্রেস এবং ফুল স্ট্যাক ওয়েব ডেভেলপার। কাস্টম ই-কমার্স সলিউশন এবং প্লাগইন ডেভেলপমেন্টে পারদর্শী।</p>
                <div style="margin-top: 10px; font-size: 13px;">
                    <span style="margin-right: 15px;"><strong>মোবাইল:</strong> 01756671617</span>
                    <span><strong>ওয়েবসাইট:</strong> codewithrakib.com</span>
                </div>
                <a href="https://wa.me/8801756671617" target="_blank" class="dev-contact">সরাসরি যোগাযোগ করুন</a>
            </div>
        </div>
    </div>
    <?php
}